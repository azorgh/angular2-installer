import {Component} from 'angular2/core';

@Component({
	selector: 'my-app',
	template: `Hello World`,
})

export class AppComponent {
}

